//specifying the database schema
const mongoose = require('mongoose')

const postschema = mongoose.Schema(
    {
        postid: {type: String, required:true},
        postname: {type: String, required: true},
        postCategory: {type: String, required: true},
        postDescription: {type: String, required: true}
    }
)

module.exports = mongoose.model('Post',postschema)