const express = require ('express')
const router = express.Router();
const User = require('../models/user')
const bcrypt = require('bcrypt')                     //use for hash
const jwt = require('jsonwebtoken'); // Add this line to import jwt
const user = require('../models/user');


//signup
router.post('/signup', (req, res) => {     
   bcrypt.hash(req.body.password,10)                    //call bcrypt to hash password
   .then(hash =>{
    const user = new User ({                              //variables in the user model
            username: req.body.username,
            password: hash,
            email: req.body.email,
            cellnumber:req.body.cellnumber,
            dateOfBirth:req.body.dateOfBirth,
            department:req.body.department
        });

    
         user.save().then(result =>{
       res.status(201).json({
        message: 'User has been created',         //successful registration
        result:result
    });
   })
   .catch(err=> {
    res.status(500).json({
        error:err
    });
   });
});
})


//login 
router.post('/login', (req,res)=>{
    User.findOne({username:req.body.username})
    .then(user=>{
        if(!user){
            return res.status(401).json({
                message:"Authentication Failure"
            });
        }

        bcrypt.compare(req.body.password, user.password, (err, result) => {   //Compares the hash passwords
            if (err || !result) {
                return res.status(401).json({
                    message: "Authentication Failure"
                });
            }

            const token = jwt.sign({username:user.username,userid:user._id},
                'BRUHCODE',{expiresIn:'1h'}); 
            console.log('Login successful!'); // See if login is successful
            res.status(200).json({token:token});
        });
    })
    .catch(err => {
        return res.status(401).json({
            message:"Authentication Failure"   //Should there be an error
        });
    });
})


module.exports = router