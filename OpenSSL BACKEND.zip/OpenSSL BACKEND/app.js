const express = require('express')
const app = express()
const urlprefix = '/api'
const mongoose = require('mongoose')
const Post = require('./models/post')
const fs = require('fs');
const cert = fs.readFileSync('Keys/certificate.pem');

const options = {
    server: {sslCA: cert}};
const connString= 'mongodb+srv://st10081844:Hucklebonged92@cluster0.gnisbdn.mongodb.net/' 
const postRoutes = require("./routes/post");
const userRoutes=require("./routes/user");
mongoose.connect(connString)                 //connect to db
.then(()=>
{
    console.log('Connected :)')
})
.catch((error)=>
{
    console.error('Error:', error);
    console.log('Not Connected :(')                //Connection error
},options);

app.use(express.json())  //express is a framework

//below allows the frontend to call the backend without origin restriciton issues
app.use((reg,res,next) => 
{
   res.setHeader('Access-Control-Allow-Origin','*');
   res.setHeader('Access-Control-Allow-Headers','Origin,X-Requested-With,Content-Type,Accept,Authorization');
   res.setHeader('Access-Control-Allow-Methods','*'); 
   next(); 
});

app.get(urlprefix +'/',(req, res) => {
    res.send('Hello World')

})

app.use(urlprefix+'/posts',postRoutes)
app.use(urlprefix+'/users',userRoutes)

module.exports = app;




